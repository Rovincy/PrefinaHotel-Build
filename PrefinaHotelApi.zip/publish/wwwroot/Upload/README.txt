Alfresco Community (Build: 7.2.0.1)
===============================

Contains:
	- Alfresco Content Services Community:	7.2.0.1
	- Alfresco Repository:	14.147
	- Alfresco Share:		14.98

For users of Alfresco Community Edition, more information on this release is available at https://community.alfresco.com/community/ecm
